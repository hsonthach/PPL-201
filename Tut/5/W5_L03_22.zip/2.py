
import itertools

lst = [[0, 1], [2, 3]]


def flattenA(lst):
    return list(itertools.chain.from_iterable(lst))


def flattenB(lst):
    if lst:
        return lst[0] + flatten_b(lst[1:])
    else:
        return []


def flatten(lst):
    return list(reduce(lambda x, y: x + y, lst))
